require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, '../public')));

// ─── MongoDB Connection ────────────────────────────────────────────────────────
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB error:', err));

// ─── Schemas ──────────────────────────────────────────────────────────────────
const userSchema = new mongoose.Schema({
  firstName:  { type: String, required: true, trim: true },
  lastName:   { type: String, required: true, trim: true },
  email:      { type: String, required: true, unique: true, lowercase: true },
  password:   { type: String, required: true },
  course:     { type: String, default: 'BCA' },
  createdAt:  { type: Date, default: Date.now }
});

const activitySchema = new mongoose.Schema({
  email:  { type: String, required: true },
  action: { type: String, required: true },   // LOGIN | VIEW_PAGE | LOGOUT
  page:   { type: String, default: '' },
  time:   { type: Date, default: Date.now }
});

const User     = mongoose.model('User', userSchema);
const Activity = mongoose.model('Activity', activitySchema);

// ─── Helpers ──────────────────────────────────────────────────────────────────
const gmailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;

const authMiddleware = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No token provided' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(403).json({ message: 'Invalid or expired token' });
  }
};

const adminMiddleware = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No admin token' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded.role !== 'admin') return res.status(403).json({ message: 'Not admin' });
    req.admin = decoded;
    next();
  } catch {
    res.status(403).json({ message: 'Invalid admin token' });
  }
};

// ─── Routes ───────────────────────────────────────────────────────────────────

// POST /api/register
app.post('/api/register', async (req, res) => {
  try {
    const { firstName, lastName, email, password, course } = req.body;

    if (!firstName || !lastName || !email || !password || !course)
      return res.status(400).json({ message: 'All fields are required' });

    if (!gmailRegex.test(email))
      return res.status(400).json({ message: 'Only Gmail addresses are allowed' });

    if (password.length < 6 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password))
      return res.status(400).json({ message: 'Password must be ≥6 chars and contain a letter & number' });

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing)
      return res.status(409).json({ message: 'Email already registered. Please login.' });

    const hashed = await bcrypt.hash(password, 10);
    await User.create({ firstName, lastName, email: email.toLowerCase(), password: hashed, course });

    res.status(201).json({ message: 'Registration successful! Please login.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error during registration' });
  }
});

// POST /api/login
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password)
      return res.status(400).json({ message: 'Email and password required' });

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user)
      return res.status(404).json({ message: 'Please register first' });

    const match = await bcrypt.compare(password, user.password);
    if (!match)
      return res.status(401).json({ message: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user._id, email: user.email, firstName: user.firstName, lastName: user.lastName, role: 'user' },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    await Activity.create({ email: user.email, action: 'LOGIN', page: 'index.html' });

    res.json({ token, user: { firstName: user.firstName, lastName: user.lastName, email: user.email, course: user.course } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error during login' });
  }
});

// POST /api/admin-login
app.post('/api/admin-login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (email !== process.env.ADMIN_EMAIL || password !== process.env.ADMIN_PASSWORD)
      return res.status(401).json({ message: 'Invalid admin credentials' });

    const token = jwt.sign(
      { email, role: 'admin' },
      process.env.JWT_SECRET,
      { expiresIn: '1d' }
    );

    res.json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error during admin login' });
  }
});

// POST /api/logout
app.post('/api/logout', authMiddleware, async (req, res) => {
  try {
    await Activity.create({ email: req.user.email, action: 'LOGOUT', page: 'dashboard.html' });
    res.json({ message: 'Logged out successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Server error during logout' });
  }
});

// GET /api/profile
app.get('/api/profile', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Server error fetching profile' });
  }
});

// GET /api/users  (admin only)
app.get('/api/users', adminMiddleware, async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: 'Server error fetching users' });
  }
});

// GET /api/activity  (admin only)
app.get('/api/activity', adminMiddleware, async (req, res) => {
  try {
    const logs = await Activity.find().sort({ time: -1 }).limit(200);
    res.json(logs);
  } catch (err) {
    res.status(500).json({ message: 'Server error fetching activity' });
  }
});

// POST /api/activity
app.post('/api/activity', authMiddleware, async (req, res) => {
  try {
    const { action, page } = req.body;
    await Activity.create({ email: req.user.email, action, page });
    res.json({ message: 'Activity recorded' });
  } catch (err) {
    res.status(500).json({ message: 'Server error recording activity' });
  }
});

// ─── Serve HTML pages ─────────────────────────────────────────────────────────
app.get('/', (req, res) => res.sendFile(path.join(__dirname, '../public/index.html')));

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));
